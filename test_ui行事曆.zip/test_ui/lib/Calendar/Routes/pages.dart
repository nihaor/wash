class Pages {
  static const task = '/tasks';
  static const createNewTask = '/createNewTask';
  static const updateTask = '/updateNewTask';
}
