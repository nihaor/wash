import 'package:flutter/material.dart';
import 'package:test_ui/Calendar/Routes/pages.dart';
import 'package:test_ui/Calendar/Tasks/Data/Repository/task_repository.dart';
import '../Tasks/Data/Local/Model/task_model.dart';
import '../Tasks/Presentation/Bloc/tasks_bloc.dart';
import '../Tasks/Presentation/Pages/new_task_screen.dart';
import '../Tasks/Presentation/Pages/task_screen.dart';
import '../Tasks/Presentation/Pages/update_task_screen.dart';
import '../page_not_found.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

Route onGenerateRoute(RouteSettings routeSettings, TaskRepository taskRepository) {
  switch (routeSettings.name) {
    case Pages.task:
      return MaterialPageRoute(
        builder: (context) => const TasksScreen(),
      );
    case Pages.createNewTask:
      return MaterialPageRoute(
        builder: (context) => const NewTaskScreen(),
      );
    case Pages.updateTask:
      final args = routeSettings.arguments as TaskModel;
      return MaterialPageRoute(
        builder: (context) => UpdateTaskScreen(taskModel: args),
      );
    default:
      return MaterialPageRoute(
        builder: (context) => const PageNotFound(),
      );
  }
}
