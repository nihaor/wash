class Constants{
  static const String taskKey = 'tasks';
}