const double textTiny = 10.0;
const double textSmall = 12.0;
const double textMedium = 14.0;
const double textExtraLarge = 18.0;
const double textXExtraLarge = 20.0;
const double textBold = 30.0;