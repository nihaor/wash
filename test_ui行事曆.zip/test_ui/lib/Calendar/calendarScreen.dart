import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'Tasks/Data/Local/Model/task_model.dart';
import 'Tasks/Data/Repository/task_repository.dart';
import 'Tasks/Presentation/Bloc/tasks_bloc.dart';
import 'Tasks/Presentation/Pages/new_task_screen.dart';
import 'Tasks/Presentation/Pages/task_screen.dart';
import 'Tasks/Presentation/Pages/update_task_screen.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CalendarScreen extends StatelessWidget {
  final TaskRepository taskRepository;

  CalendarScreen({Key? key, required this.taskRepository}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider<TasksBloc>(
      create: (context) => TasksBloc(taskRepository),
      child: MaterialApp(
        home: TasksScreen(), // 設定首頁
        routes: {
          '/createNewTask': (context) => NewTaskScreen(),
          // 使用 onGenerateRoute 來傳遞參數
          '/updateNewTask': (context) => UpdateTaskScreen(
            taskModel: ModalRoute.of(context)!.settings.arguments as TaskModel,
          ),
        },
      ),
    );
  }
}
