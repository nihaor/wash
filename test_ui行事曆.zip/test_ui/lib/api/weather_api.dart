import '../Weather/Location/open_weather_map_client.dart';
import '../Weather/Models/weather_result.dart';

const apiKey = '315e1b7750d37ff82a3370a0dd3057c5';
const apiEndpoint = 'https://api.openweathermap.org/data/2.5';