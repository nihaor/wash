import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';
import 'event_provider.dart';
import 'event.dart';
import 'package:test_ui/firemesssage/notification_helper.dart';

class Calendar2Screen extends StatefulWidget {
  @override
  _Calendar2ScreenState createState() => _Calendar2ScreenState();
}

class _Calendar2ScreenState extends State<Calendar2Screen> {
  late final NotificationHelper _notificationHelper;
  final TextEditingController _titleController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  late Map<DateTime, List<Event>> _events; // 用於存儲事件列表
  int n = 1;
  @override
  void initState() {
    n = 0;
    super.initState();
    _notificationHelper = NotificationHelper();
    _notificationHelper.initialize();
    _events = {}; // 初始化事件列表
  }

  // 格式化日期，僅保留年月日，忽略時間
  DateTime _stripTime(DateTime date) {
    return DateTime(date.year, date.month, date.day);
  }

  Future<void> _selectDate() async {
    DateTime currentDate = DateTime.now();
    DateTime initialDate = _selectedDate ?? currentDate;

    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: currentDate,
      lastDate: DateTime(currentDate.year + 1),
    );

    if (pickedDate != null) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  Future<void> _selectTime() async {
    TimeOfDay initialTime = _selectedTime ?? TimeOfDay.now();

    TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: initialTime,
    );

    if (pickedTime != null) {
      setState(() {
        _selectedTime = pickedTime;
      });
    }
  }

  void _addEvent() {
    n = n + 1;
    if (_titleController.text.isEmpty || _selectedDate == null || _selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('請填寫所有欄位')),
      );
      return;
    }

    final DateTime eventDateTime = DateTime(
      _selectedDate!.year,
      _selectedDate!.month,
      _selectedDate!.day,
      _selectedTime!.hour,
      _selectedTime!.minute,
    );

    final event = Event(
      id: n.toString(),
      title: _titleController.text,
      description: '這是測試事件',
      startTime: eventDateTime,
      endTime: eventDateTime.add(Duration(hours: 1)),
      reminderTime: eventDateTime.subtract(Duration(minutes: 0)),
    );

    final eventDate = _stripTime(_selectedDate!);
    if (_events[eventDate] != null) {
      _events[eventDate]!.add(event);
    } else {
      _events[eventDate] = [event];
    }

    Provider.of<EventProvider>(context, listen: false).addEvent(event);
    _notificationHelper.scheduleNotification(event.title, event.reminderTime);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('事件已安排')),
    );

    setState(() {
      _titleController.clear();
      _selectedDate = null;
      _selectedTime = null;
    });
    n=n+1;
  }

  void _onDaySelected(DateTime selectedDay, DateTime focusedDay) {
    setState(() {
      _selectedDate = selectedDay;
    });

    final events = _events[_stripTime(selectedDay)] ?? [];
    if (events.isNotEmpty) {
      _showEventList(events);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('當天沒有事件')),
      );
    }
  }

  void _showEventList(List<Event> events) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return ListView.builder(
          itemCount: events.length,
          itemBuilder: (context, index) {
            final event = events[index];
            return ListTile(
              title: Text(event.title),
              subtitle: Text(event.startTime.toString()),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () => _editEvent(event),
                  ),
                  IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () => _deleteEvent(event),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _editEvent(Event event) {
    _titleController.text = event.title;
    _selectedDate = event.startTime;
    _selectedTime = TimeOfDay.fromDateTime(event.startTime);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('編輯事件'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _titleController,
                decoration: InputDecoration(labelText: '事件標題'),
              ),
              ElevatedButton(
                onPressed: _selectDate,
                child: Text(
                  _selectedDate == null
                      ? '選擇日期'
                      : '選擇日期: ${_selectedDate!.toLocal().toShortDateString()}',
                ),
              ),
              ElevatedButton(
                onPressed: _selectTime,
                child: Text(
                  _selectedTime == null
                      ? '選擇時間'
                      : '選擇時間: ${_selectedTime!.format(context)}',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('取消'),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _saveEditedEvent(event);
                  event.isChanged = true; // 標記事件為已更改
                });
                Navigator.of(context).pop();
              },
              child: Text('保存'),
            ),
          ],
        );
      },
    );
  }

  void _saveEditedEvent(Event event) {
    setState(() {
      // 保存事件的原始日期
      final oldEventDate = _stripTime(event.startTime);
      // 更新事件的標題和時間
      event.title = _titleController.text;
      event.startTime = DateTime(
        _selectedDate!.year,
        _selectedDate!.month,
        _selectedDate!.day,
        _selectedTime!.hour,
        _selectedTime!.minute,
      );
      event.endTime = event.startTime.add(Duration(hours: 1));
      // 根據新的開始時間更新提醒時間
      event.reminderTime = event.startTime.subtract(Duration(minutes:0));

      // 如果事件日期改變，將事件從舊日期移到新日期
      final newEventDate = _stripTime(event.startTime);
      if (oldEventDate != newEventDate) {
      // 從舊的日期中移除事件
      _events[oldEventDate]?.remove(event);
      if (_events[oldEventDate]?.isEmpty ?? false) {
      _events.remove(oldEventDate); // 如果該日期的事件為空，移除該日期
      }

      // 添加事件到新的日期
      if (_events[newEventDate] != null) {
      _events[newEventDate]!.add(event);
      } else {
      _events[newEventDate] = [event];
      }
      }
    });


    // 取消舊的通知
    _notificationHelper.cancelNotification(event.id);
    // 重新安排新通知
    _notificationHelper.scheduleNotification(event.title, event.reminderTime);

    // 清空輸入框
    _titleController.clear();

    ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text('事件已更新並重新安排通知')),
    );
  }

  void _deleteEvent(Event event) {

    setState(() {
      final eventDate = _stripTime(event.startTime);
      _events[eventDate]?.remove(event);
      if (_events[eventDate]?.isEmpty ?? false) {
        _events.remove(eventDate);
      }
    });

    // 取消通知
    _notificationHelper.cancelNotification(event.id);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('事件已刪除')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('行事曆提醒'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            TableCalendar(
              firstDay: DateTime.utc(2020, 1, 1),
              lastDay: DateTime.utc(2030, 12, 31),
              focusedDay: DateTime.now(),
              selectedDayPredicate: (day) => isSameDay(_selectedDate, day),
              eventLoader: (day) {
                final events = _events[_stripTime(day)] ?? [];
                return events.map((event) {
                  // 根據事件狀態返回不同的圖標顏色
                  if (event.isDeleted) {
                    return Icon(Icons.cancel, color: Colors.grey); // 被刪除的事件顯示灰色
                  } else if (event.isChanged) {
                    return Icon(Icons.star, color: Colors.yellow); // 被更改的事件顯示黃色星星
                  } else {
                    return Icon(Icons.event, color: Colors.blue); // 普通事件顯示藍色
                  }
                }).toList();
              },
              onDaySelected: _onDaySelected,
              calendarStyle: CalendarStyle(
                todayDecoration: BoxDecoration(
                  color: Colors.orange,
                  shape: BoxShape.circle,
                ),
                selectedDecoration: BoxDecoration(
                  color: Colors.blue,
                  shape: BoxShape.circle,
                ),
                markerDecoration: BoxDecoration(
                  color: Colors.red,
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: _titleController,
                    decoration: InputDecoration(labelText: '事件標題'),
                  ),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _selectDate,
                          child: Text(
                            _selectedDate == null
                                ? '選擇日期'
                                : '選擇日期: ${_selectedDate!.toLocal().toShortDateString()}',
                          ),
                        ),
                      ),
                      SizedBox(width: 16),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _selectTime,
                          child: Text(
                            _selectedTime == null
                                ? '選擇時間'
                                : '選擇時間: ${_selectedTime!.format(context)}',
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _addEvent,
                    child: Text('新增事件並安排通知'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

extension on DateTime {
  String toShortDateString() {
    return '${this.day}/${this.month}/${this.year}';
  }
}
