import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

class ReminderService {
  final FlutterLocalNotificationsPlugin _localNotificationsPlugin = FlutterLocalNotificationsPlugin();

  // 初始化本地通知
  void initialize() {
    const AndroidInitializationSettings initializationSettingsAndroid = AndroidInitializationSettings('app_icon');
    final InitializationSettings initializationSettings = InitializationSettings(android: initializationSettingsAndroid);
    _localNotificationsPlugin.initialize(initializationSettings);
  }

  // 顯示本地通知
  Future<void> showLocalNotification(String title, String body) async {
    var androidDetails = const AndroidNotificationDetails(
      'channelId', 'channelName',
      importance: Importance.max,
    );
    var generalNotificationDetails = NotificationDetails(android: androidDetails);
    await _localNotificationsPlugin.show(0, title, body, generalNotificationDetails);
  }

  // 設置遠程通知 (透過 FCM)
  void initializeFCM() {
    FirebaseMessaging.instance.subscribeToTopic('reminder_notifications');
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      if (message.notification != null) {
        showLocalNotification(message.notification!.title!, message.notification!.body!);
      }
    });
  }
}
