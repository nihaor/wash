import 'package:flutter/material.dart';
import 'firestore_service.dart';
import 'event.dart';

class EventProvider with ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();

  List<Event> _events = [];

  List<Event> get events => _events;

  // 獲取事件
  void fetchEvents() {
    _firestoreService.getEvents().listen((eventList) {
      _events = eventList;
      notifyListeners();
    });
  }

  List<Event> getEventsForDay(DateTime date) {
    return _events.where((event) =>
    event.startTime.year == date.year &&
        event.startTime.month == date.month &&
        event.startTime.day == date.day
    ).toList();
  }

  // 添加事件
  Future<void> addEvent(Event event) async {
    await _firestoreService.addEvent(event);
    fetchEvents();  // 添加事件後刷新事件列表
  }

  // 更新事件
  Future<void> updateEvent(Event event) async {
    await _firestoreService.updateEvent(event);
    fetchEvents();  // 更新事件後刷新事件列表
  }

  // 刪除事件
  Future<void> deleteEvent(String eventId) async {
    await _firestoreService.deleteEvent(eventId);
    fetchEvents();  // 刪除事件後刷新事件列表
  }
}
