import 'package:cloud_firestore/cloud_firestore.dart';
import 'event.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // 儲存事件到 Firestore
  Future<void> addEvent(Event event) {
    return _db.collection('events').add(event.toMap());
  }

  // 獲取所有事件
  Stream<List<Event>> getEvents() {
    return _db.collection('events').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) => Event.fromMap(doc.data() as Map<String, dynamic>, doc.id)).toList();
    });
  }

  // 更新事件
  Future<void> updateEvent(Event event) {
    return _db.collection('events').doc(event.id).update(event.toMap());
  }

  // 刪除事件
  Future<void> deleteEvent(String eventId) {
    return _db.collection('events').doc(eventId).delete();
  }
}
