import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';


class UserWidget extends StatefulWidget {
  @override
  _UserWidgetState createState() => _UserWidgetState();
}

class _UserWidgetState extends State<UserWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
        width: 360,
        height: 640,
        decoration: BoxDecoration(
          color : Color.fromRGBO(232, 252, 255, 1),
        ),
        child: Stack(
            children: <Widget>[
              Positioned(  //更換照片
                  top: 250,
                  left: 10,
                  right: 10,
                  child: TextButton(
                      onPressed: () {
                        //更換照片
                      },
                      child: Container(
                        width: 180,
                        height: 50,
                        decoration: BoxDecoration(
                          borderRadius : BorderRadius.only(
                            topLeft: Radius.circular(30),
                            topRight: Radius.circular(30),
                            bottomLeft: Radius.circular(30),
                            bottomRight: Radius.circular(30),
                          ),
                          color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10).copyWith(right: 5, left: 52, top: 10, bottom: 10),
                        child: Row(
                          children: <Widget>[
                            Text(
                              '更換照片',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  decoration: TextDecoration.none,
                                  color: Color.fromRGBO(0, 0, 0, 1),
                                  fontFamily: 'MPLUSRounded1c',
                                  fontSize: 18,
                                  height: 1
                              ),
                            ),
                          ],
                        ),
                      )
                  )
              ),
              Positioned(  //確認修改
                  top: 700,
                  left: 25,
                  child: TextButton(
                      onPressed: () {
                        //確認修改
                      },
                      child: Container(
                        width: 140,
                        height: 50,
                        decoration: BoxDecoration(
                          borderRadius : BorderRadius.only(
                            topLeft: Radius.circular(30),
                            topRight: Radius.circular(30),
                            bottomLeft: Radius.circular(30),
                            bottomRight: Radius.circular(30),
                          ),
                          color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10).copyWith(right: 5, left: 30, top: 10, bottom: 10),
                        child: Row(
                          children: <Widget>[
                            Text(
                              '確認修改',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  decoration: TextDecoration.none,
                                  color: Color.fromRGBO(0, 0, 0, 1),
                                  fontFamily: 'MPLUSRounded1c',
                                  fontSize: 18,
                                  height: 1
                              ),
                            ),
                          ],
                        ),
                      )
                  )
              ),
              Positioned(  //登出
                  top: 700,
                  right: 25,
                  child: TextButton(
                      onPressed: () {
                        //登出
                      },
                      child: Container(
                        width: 140,
                        height: 50,
                        decoration: BoxDecoration(
                          borderRadius : BorderRadius.only(
                            topLeft: Radius.circular(30),
                            topRight: Radius.circular(30),
                            bottomLeft: Radius.circular(30),
                            bottomRight: Radius.circular(30),
                          ),
                          color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10).copyWith(right: 5, left: 51, top: 10, bottom: 10),
                        child: Row(
                          children: <Widget>[
                            Text(
                              '登出',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  decoration: TextDecoration.none,
                                  color: Color.fromRGBO(0, 0, 0, 1),
                                  fontFamily: 'MPLUSRounded1c',
                                  fontSize: 18,
                                  height: 1
                              ),
                            ),
                          ],
                        ),
                      )
                  )
              ),
              Positioned( //放大頭照的地方
                  top: 42,
                  left: 84,
                  child: Container(
                      width: 191,
                      height: 191,
                      decoration: BoxDecoration(
                        borderRadius : BorderRadius.only(
                          topLeft: Radius.circular(25),
                          topRight: Radius.circular(25),
                          bottomLeft: Radius.circular(25),
                          bottomRight: Radius.circular(25),
                        ),
                        color : Color.fromRGBO(184, 231, 251, 1),
                      ),
                      child: Stack(
                          children: <Widget>[
                            Positioned(
                                top: 17.88595199584961,
                                left: 17.912370681762695,
                                child: SvgPicture.asset(
                                    'assets/images/vector.svg',
                                    semanticsLabel: 'vector'
                                )
                            ),
                          ]
                      )
                  )
              ),
              Positioned(
                  top: 320,
                  left: 37,
                  child: Container(
                      height: 30,
                      child: Text(
                        '姓名',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            color: Color.fromRGBO(0, 0, 0, 1),
                            fontFamily: 'MPLUSRounded1c',
                            fontSize: 20,
                            height: 1
                        ),
                      )
                  )
              ),
              Positioned(
                  top: 400,
                  left: 37,
                  child: Container(
                      height: 30,
                      child: Text(
                        '電子郵件',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            color: Color.fromRGBO(0, 0, 0, 1),
                            fontFamily: 'MPLUSRounded1c',
                            fontSize: 20,
                            height: 1
                        ),
                      )
                  )
              ),
              Positioned(
                  top: 484,
                  left: 37,
                  child: Container(
                      height: 30,
                      child: Text(
                        '密碼',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            decoration: TextDecoration.none,
                            color: Color.fromRGBO(0, 0, 0, 1),
                            fontFamily: 'MPLUSRounded1c',
                            fontSize: 20,
                            height: 1
                        ),
                      )
                  )
              ),
              Positioned(
                  top: 349,
                  left: 40,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius : BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                      boxShadow : [BoxShadow(
                          color: Color.fromRGBO(0, 0, 0, 0.05000000074505806),
                          offset: Offset(0,1),
                          blurRadius: 2
                      )],
                      color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,

                      children: <Widget>[

                      ],
                    ),
                  )
              ),
              Positioned(
                  top: 432,
                  left: 40,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius : BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                      boxShadow : [BoxShadow(
                          color: Color.fromRGBO(0, 0, 0, 0.05000000074505806),
                          offset: Offset(0,1),
                          blurRadius: 2
                      )],
                      color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,

                      children: <Widget>[

                      ],
                    ),
                  )
              ),
              Positioned(
                  top: 516,
                  left: 40,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius : BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                        bottomLeft: Radius.circular(30),
                        bottomRight: Radius.circular(30),
                      ),
                      boxShadow : [BoxShadow(
                          color: Color.fromRGBO(0, 0, 0, 0.05000000074505806),
                          offset: Offset(0,1),
                          blurRadius: 2
                      )],
                      color : Color.fromRGBO(255, 255, 255, 0.6000000238418579),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,

                      children: <Widget>[

                      ],
                    ),
                  )
              ),
              Positioned(
                  top: 520,
                  left: 241,
                  child: Text('忘記密碼', textAlign: TextAlign.center, style: TextStyle(
                      color: Color.fromRGBO(0, 0, 0, 1),
                      fontFamily: 'Kanit',
                      fontSize: 16,
                      letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                      fontWeight: FontWeight.normal,
                      height: 1
                  ),)
              ),
              Positioned(
                  top: 520,
                  left: 53,
                  child: Text('**************', textAlign: TextAlign.center, style: TextStyle(
                      color: Color.fromRGBO(0, 0, 0, 1),
                      fontFamily: 'Kanit',
                      fontSize: 16,
                      letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                      fontWeight: FontWeight.normal,
                      height: 1
                  ),)
              ),
              Positioned(
                  top: 436,
                  left: 55,
                  child: Text('a123456789@gmail.com', textAlign: TextAlign.center, style: TextStyle(
                      color: Color.fromRGBO(0, 0, 0, 1),
                      fontFamily: 'Kanit',
                      fontSize: 16,
                      letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                      fontWeight: FontWeight.normal,
                      height: 1
                  ),)
              ),
              Positioned(
                  top: 353,
                  left: 55,
                  child: Text('王曉明', textAlign: TextAlign.center, style: TextStyle(
                      color: Color.fromRGBO(0, 0, 0, 1),
                      fontFamily: 'Kanit',
                      fontSize: 16,
                      letterSpacing: 0 /*percentages not used in flutter. defaulting to zero*/,
                      fontWeight: FontWeight.normal,
                      height: 1
                  ),)
              ),
              Positioned(  //返回鍵
                  top: 25,
                  left: 20,
                  child: Container(
                      width: 25,
                      height: 25,
                      child: Stack(
                          children: <Widget>[
                            Positioned(
                                top: -12,
                                left: -13,
                                child: IconButton(
                                  onPressed: () {
                                    Navigator.pop(context); //跳回上一頁
                                  },
                                  icon: Icon(
                                    Icons.arrow_back,
                                    size: 30,
                                  ),
                                )
                            ),
                          ]
                      )
                  )
              ),
            ]
        )
    );
  }
}