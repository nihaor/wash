import 'package:flutter/material.dart';
import 'package:test_ui/main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../Calendar/Tasks/Data/Local/Data_Sources/tasks_data_provider.dart';
import '../Calendar/Tasks/Data/Repository/task_repository.dart';
import 'guide2.dart';

class Guide1Widget extends StatefulWidget {
  @override
  _Guide1WidgetState createState() => _Guide1WidgetState();
}

class _Guide1WidgetState extends State<Guide1Widget> {
  late SharedPreferences preferences;
  late TaskRepository taskRepository;

  @override
  void initState() {
    super.initState();
    // 確保這裡的 preferences 和 taskRepository 已經初始化
    initPreferencesAndRepository();
  }

  Future<void> initPreferencesAndRepository() async {
    preferences = await SharedPreferences.getInstance();
    taskRepository = TaskRepository(taskDataProvider: TaskDataProvider(preferences));
    setState(() {}); // 更新狀態以確保 widget 正確加載
  }

  @override
  Widget build(BuildContext context) {
    if (preferences == null || taskRepository == null) {
      return Center(child: CircularProgressIndicator());
    }

    return GestureDetector(
      onHorizontalDragEnd: (DragEndDetails details) {
        if (details.primaryVelocity! < 0) {
          // 左滑
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => Guide2Widget()), // 跳到導覽頁2
          );
        } else {
          // 右滑
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => InitialWidget(
                taskRepository: taskRepository,
                preferences: preferences,
              ),
            ), // 跳到初始頁
          );
        }
      },
      child: Container(
        width: 360,
        height: 640,
        decoration: BoxDecoration(
          color: Color.fromRGBO(232, 252, 255, 1),
        ),
        child: Stack(
          children: <Widget>[
            Positioned(
              top: 740,
              left: 145,
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(255, 255, 255, 1),
                  border: Border.all(
                    color: Color.fromRGBO(0, 102, 254, 1),
                    width: 1,
                  ),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Positioned(
              top: 740,
              left: 185,
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(217, 217, 217, 0),
                  border: Border.all(
                    color: Color.fromRGBO(0, 102, 254, 1),
                    width: 1,
                  ),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Positioned(
              top: 740,
              left: 225,
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(217, 217, 217, 0),
                  border: Border.all(
                    color: Color.fromRGBO(0, 102, 254, 1),
                    width: 1,
                  ),
                  shape: BoxShape.circle,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
