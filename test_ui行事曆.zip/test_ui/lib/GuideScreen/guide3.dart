import 'package:flutter/material.dart';

import '../SignInSignUp/signup_signin.dart';
import 'guide2.dart';

//導覽頁3
class Guide3Widget extends StatefulWidget {
  @override
  _Guide3WidgetState createState() => _Guide3WidgetState();
}

class _Guide3WidgetState extends State<Guide3Widget> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onHorizontalDragEnd: (DragEndDetails details) {
          if(details.primaryVelocity! < 0){
            //左滑
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Signin_signupWidget()), //跳到登入註冊畫面
            );
          }
          else{
            //右滑
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Guide2Widget()), //跳到導覽頁2
            );
          }
        },
      child: Container(
        width: 360,
        height: 640,
        decoration: BoxDecoration(
          color : Color.fromRGBO(232, 252, 255, 1),
        ),
        child: Stack(
            children: <Widget>[
              Positioned(
                  top: 740,
                  left: 145,
                  child: Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color : Color.fromRGBO(255, 255, 255, 0),
                        border : Border.all(
                          color: Color.fromRGBO(0, 102, 254, 1),
                          width: 1,
                        ),
                        borderRadius : BorderRadius.all(Radius.elliptical(24, 24)),
                      )
                  )
              ),
              Positioned(
                  top: 740,
                  left: 185,
                  child: Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color : Color.fromRGBO(217, 217, 217, 0),
                        border : Border.all(
                          color: Color.fromRGBO(0, 102, 254, 1),
                          width: 1,
                        ),
                        borderRadius : BorderRadius.all(Radius.elliptical(24, 24)),
                      )
                  )
              ),
              Positioned(
                  top: 740,
                  left: 225,
                  child: Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color : Color.fromRGBO(255, 255, 255, 1),
                        border : Border.all(
                          color: Color.fromRGBO(0, 102, 254, 1),
                          width: 1,
                        ),
                        borderRadius : BorderRadius.all(Radius.elliptical(24, 24)),
                      )
                  )
              ),
            ]
        )
      )
    );
  }
}
