import 'package:flutter/material.dart';

import 'guide1.dart';
import 'guide3.dart';

//導覽頁2
class Guide2Widget extends StatefulWidget {
  @override
  _Guide2WidgetState createState() => _Guide2WidgetState();
}

class _Guide2WidgetState extends State<Guide2Widget> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onHorizontalDragEnd: (DragEndDetails details) {
          if(details.primaryVelocity! < 0){
            //左滑
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Guide3Widget()), // 跳到導覽頁3
            );
          }
          else{
            //右滑
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Guide1Widget()), // 跳到導覽頁1
            );
          }
        },
      child: Container(
        width: 360,
        height: 640,
        decoration: BoxDecoration(
          color : Color.fromRGBO(232, 252, 255, 1),
        ),
        child: Stack(
            children: <Widget>[
              Positioned(
                  top: 740,
                  left: 145,
                  child: Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color : Color.fromRGBO(255, 255, 255, 0),
                        border : Border.all(
                          color: Color.fromRGBO(0, 102, 254, 1),
                          width: 1,
                        ),
                        borderRadius : BorderRadius.all(Radius.elliptical(24, 24)),
                      )
                  )
              ),
              Positioned(
                  top: 740,
                  left: 185,
                  child: Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color : Color.fromRGBO(255, 253, 253, 1),
                        border : Border.all(
                          color: Color.fromRGBO(0, 102, 254, 1),
                          width: 1,
                        ),
                        borderRadius : BorderRadius.all(Radius.elliptical(24, 24)),
                      )
                  )
              ),
              Positioned(
                  top: 740,
                  left: 225,
                  child: Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color : Color.fromRGBO(217, 217, 217, 0),
                        border : Border.all(
                          color: Color.fromRGBO(0, 102, 254, 1),
                          width: 1,
                        ),
                        borderRadius : BorderRadius.all(Radius.elliptical(24, 24)),
                      )
                  )
              ),
            ]
        )
    )
    );
  }
}