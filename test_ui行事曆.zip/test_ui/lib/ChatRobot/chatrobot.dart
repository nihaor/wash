import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:dash_chat_2/dash_chat_2.dart';

const String apiKey = "sk-proj-7NA7kMd3AWkifUUoaud8T3BlbkFJnmnQZubmwQDZhXz0ovfP";
const String model = "ft:gpt-3.5-turbo-0125:personal::9RubavzI";
//new))  ft:gpt-3.5-turbo-0125:personal::9RubavzI
//old))  ft:gpt-3.5-turbo-0125:personal::9Mnu9l7J
const String apiUrl = "https://api.openai.com/v1/chat/completions";

class ChatPage extends StatefulWidget {
  @override
  _ChatPageState createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final ChatUser _currentUser = ChatUser(id: '1', firstName: 'User');
  final ChatUser _gptChatUser = ChatUser(id: '2', firstName: '衣物小幫手', profileImage: "assets/icons/robot.png");

  List<ChatMessage> _messages = [];
  List<ChatUser> _typingUsers = [];

  void getChatResponse(ChatMessage message) async {
    setState(() {
      _messages.insert(0, message);
      _typingUsers.add(_gptChatUser);
    });

    final List<Map<String, String>> messagesForApi = _messages.reversed.map((m) {
      if (m.user.id == _currentUser.id) {
        return {"role": "user", "content": m.text};
      } else {
        return {"role": "assistant", "content": m.text};
      }
    }).toList();

    final body = jsonEncode({
      "model": model,
      "messages": [
        {"role": "system", "content": "你是一個了解如何洗衣服，並且懂現在時下流行的穿搭的人"},
        ...messagesForApi
      ],
      //"max_tokens": 150,
    });

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {
        "Authorization": "Bearer $apiKey",
        "Content-Type": "application/json",
      },
      body: body,
    );

    if (response.statusCode == 200) {
      final responseData = jsonDecode(utf8.decode(response.bodyBytes));
      final fullResponse = responseData["choices"][0]["message"]["content"];

      print("API Response: $fullResponse");

      setState(() {
        _messages.insert(0, ChatMessage(
          user: _gptChatUser,
          createdAt: DateTime.now(),
          text: fullResponse,
        ));
        _typingUsers.remove(_gptChatUser);
      });
    } else {
      setState(() {
        _typingUsers.remove(_gptChatUser);
      });
      print("API Response Status Code: ${response.statusCode}");
      print("Raw API Response: ${response.body}");
      throw Exception('Failed to load response');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
            '衣物小幫手',
            style: TextStyle(
                decoration: TextDecoration.none,
                color: Colors.black,
                fontFamily: 'MPLUSRounded1c',
                fontSize: 22,
                height: 1
            ),
        ),
        backgroundColor: Color.fromRGBO(222, 243, 252, 1),
      ),
      body: Container(
        color: Colors.white,
        child: DashChat(
          currentUser: _currentUser,
          onSend: getChatResponse,
          messages: _messages,
          typingUsers: _typingUsers,
          messageOptions: MessageOptions(
            currentUserContainerColor: Color.fromRGBO(239, 238, 238, 1),
            currentUserTextColor: Colors.black,
            containerColor: Color.fromRGBO(239, 238, 238, 1),
            textColor: Colors.black,
            messagePadding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
          ),
          inputOptions: InputOptions(
            sendButtonBuilder: (VoidCallback sendMessage) {
              return Container(
                child: IconButton(
                  icon: Icon(Icons.send),
                  onPressed: sendMessage,
                  color: Colors.black,
                ),
              );
            },
            inputToolbarMargin: EdgeInsets.only(left: 5 , right: 5, top: 10, bottom: 5),
            inputToolbarPadding: EdgeInsets.symmetric(horizontal: 15, vertical: 1),
            inputTextStyle: TextStyle(
              fontSize: 15.0,
              fontFamily: 'MPLUSRounded1c',
              color: Colors.black,
            ),
            inputToolbarStyle: BoxDecoration(
              color: Color.fromRGBO(239, 238, 238, 1),
              borderRadius: BorderRadius.circular(80),
              //height: 80
            ),
            inputDecoration: InputDecoration(
              hintText: "請輸入問題",
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
            ),
            inputMaxLines: 5,
          ),
        ),
      )
    );
  }
}
